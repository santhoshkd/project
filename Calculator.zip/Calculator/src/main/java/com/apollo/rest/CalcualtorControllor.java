package com.apollo.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.apollo.dataobject.Calculation;
import com.apollo.dataobject.InputObj;
import com.apollo.dataobject.OutputObj;
import com.apollo.repo.ICalculateRepo;
import com.apollo.service.ICalcualteService;

@Controller
public class CalcualtorControllor {

	@Autowired
	ICalcualteService iCalcualteService;

	// @Autowired
	// private com.apollo.repository.CalculationRepository calculationRepository;

	@Autowired
	ICalculateRepo iCalculateRepo;

	@PostMapping(value = "/add", produces = { "application/json" }, consumes = { "application/json",
			"application/xml" })
	public @ResponseBody OutputObj add(@RequestBody InputObj inputObj) {
		OutputObj outputObj = new OutputObj();
		try {
			System.out.println("inputObjinputObjinputObj" + inputObj.getA());
			// outputObj = iCalcualteService.add(inputObj);

			outputObj.setOutput(inputObj.getA() + inputObj.getB());
			// Calculation calculation = new
			// Calculation(inputObj.getA(),inputObj.getB(),inputObj.getA() +
			// inputObj.getB(),"+");
			// calculationRepository.save(calculation);
			iCalculateRepo.save(inputObj, outputObj);

		} catch (Exception e) {
		}
		return outputObj;
	}

	@PostMapping(value = "/subtract", produces = { "application/json" }, consumes = { "application/json",
			"application/xml" })
	public @ResponseBody OutputObj subtract(@RequestBody InputObj inputObj) {
		OutputObj outputObj = new OutputObj();
		try {
			System.out.println("inputObjinputObjinputObj" + inputObj.getA());
			outputObj.setOutput(inputObj.getA() - inputObj.getB());
			iCalculateRepo.save(inputObj, outputObj);
		} catch (Exception e) {
		}
		return outputObj;
	}

	@PostMapping(value = "/multiply", produces = { "application/json" }, consumes = { "application/json",
			"application/xml" })
	public @ResponseBody OutputObj multiply(@RequestBody InputObj inputObj) {
		OutputObj outputObj = new OutputObj();
		try {
			System.out.println("inputObjinputObjinputObj" + inputObj.getA());
			outputObj.setOutput(inputObj.getA() * inputObj.getB());
			iCalculateRepo.save(inputObj, outputObj);
		} catch (Exception e) {
		}
		return outputObj;
	}

	@PostMapping(value = "/divide", produces = { "application/json" }, consumes = { "application/json",
			"application/xml" })
	public @ResponseBody OutputObj divide(@RequestBody InputObj inputObj) {
		OutputObj outputObj = new OutputObj();
		try {
			System.out.println("inputObjinputObjinputObj" + inputObj.getA());
			outputObj.setOutput(inputObj.getA() / inputObj.getB());
			iCalculateRepo.save(inputObj, outputObj);
		} catch (Exception e) {
		}
		return outputObj;
	}
}
