package com.apollo.dataobject;

public class OutputObj {	
	double output;

	public double getOutput() {
		return output;
	}

	public void setOutput(double output) {
		this.output = output;
	}
}
