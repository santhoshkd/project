package com.apollo.dataobject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The Class Calculation.
 */
@Entity
@Table(name = "CALCULATION")
public class Calculation {

	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	/** The x. */
	@Column(name= "X")
	private int x;
	
	/** The y. */
	@Column(name= "Y")
	private int y;
	
	/** The result. */
	@Column(name= "RESULT")
	private double result;
	
	/** The ops. */
	@Column(name= "OPS")
	private String ops;

	/**
	 * Instantiates a new calculation.
	 */
	public Calculation() {

	}

	/**
	 * Instantiates a new calculation.
	 *
	 * @param x the x
	 * @param y the y
	 * @param result the result
	 * @param ops the ops
	 */
	public Calculation(int x, int y, int result, String ops) {
		super();
		this.x = x;
		this.y = y;
		this.result = result;
		this.ops = ops;
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(long id) {
		this.id = id;
	}

	/**
	 * Gets the x.
	 *
	 * @return the x
	 */
	public int getX() {
		return x;
	}

	/**
	 * Sets the x.
	 *
	 * @param x the new x
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Gets the y.
	 *
	 * @return the y
	 */
	public int getY() {
		return y;
	}

	/**
	 * Sets the y.
	 *
	 * @param y the new y
	 */
	public void setY(int y) {
		this.y = y;
	}

	/**
	 * Gets the result.
	 *
	 * @return the result
	 */
	public double getResult() {
		return result;
	}

	/**
	 * Sets the result.
	 *
	 * @param result the new result
	 */
	public void setResult(double result) {
		this.result = result;
	}

	/**
	 * Gets the ops.
	 *
	 * @return the ops
	 */
	public String getOps() {
		return ops;
	}

	/**
	 * Sets the ops.
	 *
	 * @param ops the new ops
	 */
	public void setOps(String ops) {
		this.ops = ops;
	}

}
