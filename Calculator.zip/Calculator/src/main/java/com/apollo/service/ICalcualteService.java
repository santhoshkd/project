package com.apollo.service;

import com.apollo.dataobject.InputObj;
import com.apollo.dataobject.OutputObj;

public interface ICalcualteService {
OutputObj add(InputObj a);
}

