package com.apollo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.apollo.dataobject.InputObj;
import com.apollo.dataobject.OutputObj;
import com.apollo.repo.ICalculateRepo;
import com.apollo.service.ICalcualteService;
@Service
public class CalculateServiceImpl implements ICalcualteService{

	@Autowired
	ICalculateRepo iCalculateRepo;
	@Override	
	public OutputObj add(InputObj inputObj) {
		OutputObj outputObj =new OutputObj();
		outputObj.setOutput(inputObj.getA() + inputObj.getB());
		iCalculateRepo.save(inputObj,outputObj);
		return outputObj;
	}

}
