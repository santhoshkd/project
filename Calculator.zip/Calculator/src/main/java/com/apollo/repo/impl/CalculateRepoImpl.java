package com.apollo.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.apollo.dataobject.InputObj;
import com.apollo.dataobject.OutputObj;
import com.apollo.repo.ICalculateRepo;

@Repository
public class CalculateRepoImpl implements ICalculateRepo{
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	@Transactional
	public OutputObj save(InputObj inputObj, OutputObj outputObj) {
		
		jdbcTemplate.update(
		"INSERT INTO schema.CALC (ID, INPUT_A, INPUT_B, OUTPUT) VALUES (1,"+inputObj.getA()+","+inputObj.getB()+"',+"+ outputObj.getOutput()+")" );
		//new Object[]{var1, var2, var3, var4}, new Object[]{Types.TYPE_OF_VAR1, Types.TYPE_OF_VAR2, Types.TYPE_OF_VAR3, Types.TYPE_OF_VAR4} );
		return null;
	}
}
