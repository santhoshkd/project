package com.apollo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.apollo.dataobject.Calculation;

@Repository
public interface CalculationRepository extends JpaRepository<Calculation, Long>{

}
